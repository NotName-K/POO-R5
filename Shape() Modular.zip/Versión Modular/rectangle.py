from .shape import Shape
from .point import Point

class Rectangle(Shape):
    def __init__(self, length: float, width: float):
        self.__length = length
        self.__width = width
        vertices = [Point(0, 0), Point(length, 0), Point(length, width), Point(0, width)]
        super().__init__(vertices, is_regular=False)

    def compute_area(self): return self.__length * self.__width
    def compute_perimeter(self): return 2 * (self.__length + self.__width)
    def compute_inner_angles(self): return [90, 90, 90, 90]