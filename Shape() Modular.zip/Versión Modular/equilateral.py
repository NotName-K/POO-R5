import math
from .triangle import Triangle

class Equilateral(Triangle):
    def __init__(self, side):
        super().__init__(side, side, side)
        self.set_is_regular(True)

    def compute_area(self):
        a = self.get_sides()[0]
        return (math.sqrt(3) / 4) * (a ** 2)