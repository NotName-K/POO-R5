class Shape:
    def __init__(self, vertices=None, edges=None, inner_angles=None, is_regular=False):
        self.__vertices = vertices or []
        self.__edges = edges or []
        self.__inner_angles = inner_angles or []
        self.__is_regular = is_regular

    def get_vertices(self): return self.__vertices
    def set_vertices(self, vertices): self.__vertices = vertices
    def get_edges(self): return self.__edges
    def set_edges(self, edges): self.__edges = edges
    def get_inner_angles(self): return self.__inner_angles
    def set_inner_angles(self, angles): self.__inner_angles = angles
    def get_is_regular(self): return self.__is_regular
    def set_is_regular(self, value): self.__is_regular = value

    def compute_area(self): raise NotImplementedError("Método implementado por la subclase")
    def compute_perimeter(self): raise NotImplementedError("Método implementado por la subclase")
    def compute_inner_angles(self): raise NotImplementedError("Método implementado por la subclase")