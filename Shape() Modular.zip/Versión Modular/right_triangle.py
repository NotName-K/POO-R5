import math
from .triangle import Triangle

class RightTriangle(Triangle):
    def __init__(self, base, height):
        hypotenuse = math.sqrt(base**2 + height**2)
        super().__init__(base, height, hypotenuse)

    def compute_area(self):
        return (self.get_sides()[0] * self.get_sides()[1]) / 2