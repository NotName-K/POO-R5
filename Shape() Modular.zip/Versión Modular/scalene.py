from .triangle import Triangle

class Scalene(Triangle):
    def __init__(self, a, b, c):
        super().__init__(a, b, c)