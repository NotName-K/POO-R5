class Point:
    def __init__(self, x: float, y: float):
        self.__x = x
        self.__y = y

    def get_x(self): return self.__x
    def set_x(self, value): self.__x = value
    def get_y(self): return self.__y
    def set_y(self, value): self.__y = value

    def compute_distance(self, point: "Point") -> float:
        return ((self.__x - point.get_x()) ** 2 + (self.__y - point.get_y()) ** 2) ** 0.5