import math
from .triangle import Triangle

class Isosceles(Triangle):
    def __init__(self, equal_side, base):
        super().__init__(equal_side, equal_side, base)

    def compute_area(self):
        base = self.get_sides()[2]
        equal = self.get_sides()[0]
        height = math.sqrt(equal**2 - (base**2) / 4)
        return (base * height) / 2