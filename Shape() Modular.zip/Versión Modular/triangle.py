import math
from .shape import Shape

class Triangle(Shape):
    def __init__(self, a, b, c):
        if not (a + b > c and a + c > b and b + c > a):
            raise ValueError("Los lados no forman un triángulo válido.")
        self.__a = a
        self.__b = b
        self.__c = c
        super().__init__(is_regular=False)

    def get_sides(self): return self.__a, self.__b, self.__c

    def compute_perimeter(self): return self.__a + self.__b + self.__c

    def compute_area(self):
        s = self.compute_perimeter() / 2
        return math.sqrt(s * (s - self.__a) * (s - self.__b) * (s - self.__c))

    def compute_inner_angles(self):
        a, b, c = self.get_sides()
        A = math.degrees(math.acos((b ** 2 + c ** 2 - a ** 2) / (2 * b * c)))
        B = math.degrees(math.acos((a ** 2 + c ** 2 - b ** 2) / (2 * a * c)))
        C = 180 - A - B
        return [A, B, C]