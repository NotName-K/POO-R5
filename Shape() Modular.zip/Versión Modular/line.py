from .point import Point

class Line:
    def __init__(self, p_s: Point, p_e: Point):
        self.__p_s = p_s
        self.__p_e = p_e
        self.__length = self.__p_s.compute_distance(self.__p_e)

    def get_start_point(self): return self.__p_s
    def set_start_point(self, p_s: Point):
        self.__p_s = p_s
        self.__update_length()

    def get_end_point(self): return self.__p_e
    def set_end_point(self, p_e: Point):
        self.__p_e = p_e
        self.__update_length()

    def get_length(self): return self.__length

    def __update_length(self):
        self.__length = self.__p_s.compute_distance(self.__p_e)